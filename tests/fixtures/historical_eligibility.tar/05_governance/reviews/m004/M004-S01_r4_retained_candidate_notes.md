# M004-S01 round 4 retained-candidate attestation

Architect verification-only continuation, 2026-09-16, under answered Q010
(SHA-256 4dc0d2c4659d8a0b36943cd31558cd9a6522339108d9d090cf31c2edb86c89f6).
No coder dispatch, implementation edit, focused test or profile is repeated.

All twelve current product identities match the blocked round-3 manifest
05_governance/reviews/m004/M004-S01_r3_manifest_8ee230ad3060db32.json
(SHA-256 8ee230ad3060db32856c20e679ee234cc747df6175485d35be37e95d96d57ca2).
The round-3 correction changed only test_commit_v2.py; its filter precondition
and pending-state assertions require independent review with the full S01
candidate. Prior coder notes and failed/timeout evidence remain unchanged.

Q010 activates 1200 seconds for the remainder of M004 and restores 600 at
closure. It supersedes the inherited frozen 900-second envelope policy for
this execution; independent review must cite Q010. All other allowances,
prior consumption and unknown cumulative usage are unchanged. No optimization,
public /2 enablement or workspace commit is authorized.

Run exactly once using selected .venv Python 3.14.3:
python scripts/verify.py M004-S01 --timeout 1200

The command produces the authoritative receipt; this attestation does not
claim a result in advance. Failure/timeout stops for reassessment. A full pass
with zero unexpected skips and stable witness permits independent review,
not automatic acceptance. All four carried P3 findings remain carried.

## Raw identities before verification

```json
[
  {
    "path": "08_pkg/frutlups/src/frutlups/_attempts.py",
    "raw_sha256": "847dcffbef1f0f7ca08ff54c8650492489ff5c5e3aa8363e8985719bfa720b9c"
  },
  {
    "path": "08_pkg/frutlups/src/frutlups/_preflight.py",
    "raw_sha256": "90a5ac1af317b17f7cc8d38f9c4b2301bd75a229582684bad95711130811916c"
  },
  {
    "path": "08_pkg/frutlups/src/frutlups/cli.py",
    "raw_sha256": "621482859411b82c880447d482e8b9a04d58d1abb188dd45896049c19e9c115e"
  },
  {
    "path": "08_pkg/frutlups/src/frutlups/commit.py",
    "raw_sha256": "6db2ad476bd22d678032bdd8a98da3964e6b0cece2ee503b0492155382177ef8"
  },
  {
    "path": "08_pkg/frutlups/src/frutlups/gitws.py",
    "raw_sha256": "ad61f0fedef52a8b174d9b81385548d93e49ad3453c1a867fcd6dcf6c849b6e6"
  },
  {
    "path": "08_pkg/frutlups/src/frutlups/ledger.py",
    "raw_sha256": "f4c1f6b5165710c6434a8d4ea2e901402d6705268d7a7e7e584c5bac7adad8e1"
  },
  {
    "path": "08_pkg/frutlups/src/frutlups/loop.py",
    "raw_sha256": "5fbddeb18d0a89bc6a88a06d07cf29326ed47a289fba5bfa5487f9466eae6df0"
  },
  {
    "path": "08_pkg/frutlups/tests/test_cli.py",
    "raw_sha256": "5e122e77eb09873de805f440b27a2a104f91696ee52ea36b22869ceab0a7eca2"
  },
  {
    "path": "08_pkg/frutlups/tests/test_commit_v2.py",
    "raw_sha256": "a68da7dc9be6fcf8290861b381b67f1aab89c5bf7aa526fbabff9c38bab11ec7"
  },
  {
    "path": "08_pkg/frutlups/tests/test_gitws.py",
    "raw_sha256": "016ac8df8c9f8a1034d5917af05fbd8f0dc217b8d5fb33391dbd86337845f79c"
  },
  {
    "path": "08_pkg/frutlups/tests/test_incidents.py",
    "raw_sha256": "b3888c2cff450d0005dcb4409bc34d600bae3f2b8830b844cd9e49739d870691"
  },
  {
    "path": "08_pkg/frutlups/tests/test_runtime_v2.py",
    "raw_sha256": "e20f1df3a7e57523d04f422cafa16f8ab9b0953f74027ecdfdc52a607a9531e7"
  }
]
```
