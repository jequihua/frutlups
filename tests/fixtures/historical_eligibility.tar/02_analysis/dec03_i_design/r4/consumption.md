# Relevant historical uses and proposed recognition

This is a human-review basis for the three proposed DEC03-I entries, not a new
grant, complete off-ledger usage ledger, or launch-time attestation. Ledger lines
are one-based and their exact raw identities are in `occurrences.json`.
`consumption.json` binds the underlying authority, instructions and receipt facts.
The original 15-pair audit and 235,650-byte/201-line prefix are unchanged.

**Status at preparation: proposed, not adopted.** The per-entry judgements below
are conditional recommendations for explicit shared adoption. A later authority
record may adopt these exact reviewed basis/assessment bytes by raw digest and
entry identity; it must not rewrite this preparation-time status or old evidence.

| Order / authority | Observed use and evidence | Consumption / next authority | Eligibility treatment |
| --- | --- | --- | --- |
| Q004/D018, M002 | Continuing 900-second verification deadline; all other M002 limits unchanged. Resolution 58 binds Q004 and explicit architect notes; prompt 59, coded 60, verified 61, review 65, accepted 66. Receipt 632.037s versus frozen 600s. | Target action completed; no new allowance/reset inferred. Separately accepted S05 r3 receipt (632.106s under its own 900s envelope) is a predecessor bound in resolution 58, not a second use of target receipt. Cumulative 36-invocation/360-active-minute compliance remains unknown. | Propose only M002-S03 r3 at cap 900, under recorded-route rule; no certification of all original allowances. |
| Q007 / M004-S01 r1 | Coder notes at line 112 report 900.01s timeout; no successful final summary. | Failed gate requires reassessment. | No eligible receipt; context for Q008. |
| Q008/D036 / S01 r2 | Resolution 113; prompt 114, coded 115, failed verified 116. Original receipt exit 1, 892.852s, 935 passed/one failed reported. One expressly authorized 1200-second run. | One-shot action consumed by failure. It cannot support r4. Q009 authorizes bounded correction/measurement and a separate 900-second full run. | Not an accepted successful target. |
| Q009 / S01 r3 | Prompt 118; coder notes at 119 report focused/profiling work and full timeout 900.003s. The full gate is incomplete. | Q008 remains consumed; r3 does not earn a retry. Reassessment leads to Q010. Ancillary measurements are not receipts or new full-attempt permission. | Ineligible. Original notes retained; not freshly executed. |
| Q010 / S01 r4 | Resolution 120 binds Q010; prompt 122, coded 123 with explicit one-run 1200 instructions; verified 124, review 130, accepted 131. Receipt 906.514s versus frozen 900s. | Q010 supplies continuing M004 cap and expressly the first unchanged-candidate architect attempt. That r4 action is complete; cap alone gives no retry. Cumulative M004 round/seat/active-time/spend compliance remains unknown. | Propose only S01 r4 at cap 1200. Q010 prose date Sep 16 and UTC route Sep 15 are both preserved; no certification of all original allowances. |
| Q010 / S02 r1 | Accepted receipt 1134.526s under frozen 1200s. | Ordinary within-cap use. | No exception needed; not included in the three entries. |
| Q010 / S03 r1 | Prompt 139; coded notes 140 report 1025 discovered, full timeout 1200.007s with incomplete output. Recorded child exit 0 does not establish a pass. | Gate/action exhausted; Q013 grants a separate attempt. | Ineligible. |
| Q013 / S03 r2 | Resolution 141, prompt 142, instructions/coded 143, receipt/verified 144: exit 0, 1341.702s under one-shot 2400. Review 148 needs work for merge-path defect. | Verification consumed Q013 even though it passed. Review requires correction; Q013 supplies no retry. | No accepted r2 entry. Do not reuse its action for r3/r4. |
| Q014 / S03 r3 | Continuing remaining-M004 2400 cap; bounded correction plus focused and one coder full gate with stop conditions. Prompt 150/handoff 151; coded 152 reports interruption. Focused result 7299.295s with timeout flag false; full deadline observation 6101.3903121s. | Gate invalid; no automatic rerun. Available wrapper snapshot has parent 25508 and child 34976, not proven two independent attempts. Full result missing and stdout/stderr empty. Complete attempt count, active usage and process-tree disposition unknown. | Ineligible; no success, refund, cleanup proof or reset. Cap does not authorize another attempt. |
| Q015 + Q014 / S03 r4 | Owner confirms two sleeps and an awake window; resolution 153 supplies one new verification-only action. Prompt 155, coded/instructions 156, verified 157, review 160, accepted 161. Receipt exit 0, 1486.229s <=2400 versus frozen 1200. | New explicitly reassessed awake action, separate from Q013 and interrupted r3. Its completion consumes that action. Q015 explicitly retains prior usage. Cumulative M004 round/seat/active-time/spend compliance remains unknown. | Propose only r4 at cap 2400. Review must judge unknown prior active usage non-dispositive for this specific later permission; this is not proof that all prior cumulative limits were observed. |

## What the newly recovered records establish

During r3 preparation, seven exact named external files were readable and each raw digest matched the
contemporaneous r3 coder notes. `interruption_evidence.json` records byte counts,
hashes and a portable transcription; it omits resolved executable/scratch paths.
No historical command was run. The wrapper source was read as data only. R4
preserves that transcription unchanged and rechecks its bound historical notes;
it does not claim a fresh external-log read or recovered missing full result.

The full launch marker names Q014's one final-byte run and managed deadline. The
deadline observation gives a recorded launch of 14:16:25.1651314Z and observation
of 15:58:06.5554435Z on September 16, with elapsed 6101.3903121s and a reported
termination of pid 34976. Those are statements in the original observation file,
not independently measured launch/termination events today. The process snapshot
shows 34976's parent is 25508. It neither demonstrates two independent executions
nor proves all children terminated. Q015 reports the named wrappers absent at its
read-only reassessment, while expressly declining a complete process-tree audit.

`full.result.json` is absent. Both captured full output streams are zero bytes.
The focused record reports exit 0, `timed_out=false`, 7299.295s: passing stdout or
a false timeout flag cannot repair an elapsed overrun. Reliable active elapsed
through two reported sleeps and complete off-ledger consumption remain unknown.

## Conditional per-entry judgements for later explicit adoption

For the three accepted targets, use the recorded-route standard in `design.md`.
The numeric caps, source-bound resolutions, subsequent instructions and exact
successful receipts support the proposed entries; the failed/interrupted rows
cannot be used as replacement authority. Q015 is an explicit new action after
reassessment, not an inference that Q014 still had an unused attempt. Recognizing
r4 therefore need not retroactively validate r3 or reconstruct all prior usage.
These are the author's proposed judgements, not adopted exceptions:

| Exact target | Conditional judgement | Uniform allowance limit |
| --- | --- | --- |
| M002-S03 r3, accepted 66 | Eligible for historical deadline comparison at 900, citing latest resolution 58 before prompt 59; earlier 42 cannot replace it | Complete cumulative M002 usage unknown; no proof of 36-invocation/360-minute compliance |
| M004-S01 r4, accepted 131 | Eligible at 1200, citing latest resolution 120 before prompt 122; consumed Q008 at 113 cannot replace it | Complete cumulative M004 round/seat/active-time/spend compliance unknown |
| M004-S03 r4, accepted 161 | Eligible at 2400, citing latest resolution 153 before prompt 155; consumed Q013 at 141 cannot replace it | Complete cumulative M004 usage, interrupted r3 attempt count and terminal disposition unknown |

For each target these unknowns are judged non-dispositive **only for recognition
of the exact historical deadline comparison**, not overall permission/allowance
compliance. The current historical receipt consumer performs no cumulative-budget
audit; this proposal adds none and excuses no known contradiction. It does not
replenish or remove current grant, usage, retry or process-disposition checks.
Both T reviews support the three eligibility judgements according to the source
levels recorded in `review_feedback.md`; the open P2 and replacement review remain.

## Supporting chronology, with limits

`corroboration.json` binds read-only inspection of `scripts/verify.py` at
`e763871`, `5763084` and `349606e`: the three examined blobs are identical. The
function requires the ledger state to be `verifying` before `_process.run`; the
examined historical ledger fold puts a successful coded event into that state.
Conditional on the recorded route having used that code and normal append/fold
rules, this supports the coded-before-launch ordering. It is not a trace proving
which working-tree executable ran, a repository-wide immutability audit, or a
record of the timeout actually passed. The receipt still does not store that
timeout, and `timed_out=false` alone remains insufficient.

The recorded resolution-to-verified gaps are 659, 967 and 1670 seconds; the
coded-to-verified gaps are 635, 914 and 1508 seconds. Each exceeds its receipt's
632.037, 906.514 or 1486.229 seconds respectively. These are non-contradiction
checks on self-reported timestamps, not reconstructed launch times.

Q010 and its bound r4 notes say September 16; the resolution/coded events say
September 15 UTC. The commit adding Q010 records `2026-09-16T01:18:31+02:00`;
22:31 UTC maps to 00:31 September 16 at that offset. This supports a possible
local-calendar explanation but does not prove the author's date convention or
when approval was given. The commit follows verification. Preserve both dates;
prospective recognition rests on the reviewed source-bound route, not this
timezone explanation. No historical date or timestamp was corrected.

The packet does not contain independent original launch/command-start records for
the three successful target runs. If the reviewers reject recorded-route evidence,
request those exact records and withhold the affected entries. If evidence shows a
prior consumption of the exact Q015 action, a later authority, wrong candidate or
contradictory applicable allowance, withhold recognition. Unknown is never zero.

The assessment has no effect on active process handling: an unresolved invocation
today still blocks recovery/dispatch under existing rules. Historical-read
eligibility is not a declaration that an old process was safe or that a new
invocation may proceed without ordinary ownership and grant checks.

## Bound factual appendices

- `consumption.json` raw SHA-256: `16f1b8470566c7512d43d974dfd6ac4475fe8e1c0e46418d36527216a55c1d0c`.
- `occurrences.json` raw SHA-256: `6dbe0cf52a029c703ae11388c28b5f358ae6bbd54c7ac7c862e6291c990418ab`.
- `interruption_evidence.json` raw SHA-256: `d0a4684f7594ea3a1132c9ec9c58177b55887c442215594c750fea18edddbf76`.
- `corroboration.json` raw SHA-256: `b4cf0fb4e210e134222eb68d180a6ec90055db6bde321fa59e95149faf403d6e`.
- `applicability_cases.json` raw SHA-256: `7d636c2029f8fac17cbe9088ef246c5a2dbcc39249535baaa072d1899d970970`.
