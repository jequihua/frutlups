# Question: remaining M004 verification deadline after S03 review

Status: answered

- Date asked: 2026-09-16.
- Owner or likely answerer: project owner.
- What one question needs an answer? Approve a 2400-second full-verification
  deadline for the remainder of M004, including the bounded M004-S03-01
  correction and its normal coder/architect verification gates?
- Why does it block or affect the slice? S03 round-2 independent review records
  one open P2 and needs_work. The candidate passed all 1025 tests in 1341.702
  seconds under Q013, but Q013 authorized only that one attempt and is consumed.
  Q010's 1200-second default remains active. Issuing a correction with the old
  deadline would ignore the measured verification-budget mismatch.
- Current guess, explicitly not authority: use 2400 seconds through M004
  closure, then restore 600. Fix the two-file defect without mixing optimization
  into the candidate. This grants no repeat-on-failure loop and makes no claim
  of faster production execution or compliance with the old deadline.

## Concrete next work

- Architect has recorded review
  05_governance/reviews/m004/M004-S03_r2_review.md, SHA-256
  462ecf85b77cf348418843cdca57be38ee92a2b880d1802171094b6018c79b0e.
  The ledger is M004-S03 round 3, fix; no acceptance or commit is made.
- Issue the bounded correction described in
  02_analysis/M004_S03_r3_correction_plan.md: only loop.py and
  test_checkpoints_v2.py may change further. Move merged report/proof into
  Git-visible governance evidence, preserve exact restart semantics, and prove
  a routed review can complete commit-on-accept with exact committed artifacts.
  Preserve the other five retained candidate files and all original S03 gates.
- If approved, change only the roadmap full deadline from 1200 to 2400, through
  M004 closure. The historical envelope stays intact; an explicit supplement
  binds this new authority to corrective execution and independent review.
  The existing --durations=25 harness flag stays unchanged. Restore 600 at closure.
- Coder runs focused tests and the full gate once on final bytes; architect
  produces the authoritative receipt and independent review in the normal loop.
  Failure/timeout stops for reassessment; no automatic rerun, further extension,
  profiling, optimization, weaker checks, skips or reduced discovery.
- Preserve original round/seat/active-time/spend limits and prior consumption.
  Unknown totals remain unknown. No live calls, public /2 enablement, host
  change, waiver, acceptance, commit or later milestone admission is granted.

## Execution evidence

- 05_governance/reviews/m004/M004-S03_r2_verification.json, SHA-256
  45a395b49f1229be5e0299ce91ee125d710c7ba0a81f1f36a09b7d4006069a7b:
  1025 passed, zero skips, two warnings, 1341.702 seconds, stable witness.
- The 25 slowest test phases sum to 292.25 seconds. Fourteen are checkpoint
  tests, totaling 174.02 seconds; the largest is 17.61 seconds. These are
  partial timing observations, not complete module costs or internal profiling.
- The seven prior P3 findings remain unresolved at their original identities
  and dispositions; M004-S03-01 is an additional open P2 requiring correction.

## Answer

- Answered by: project owner, explicit approval in this task.
- Date answered: 2026-09-16.
- Answer: Approved 2400 seconds for remaining M004 full verification and
  continuation with the bounded two-file S03 correction. Restore 600 at closure.
- Authority: this answered Q014 and roadmap verification.timeout_seconds.
  This supersedes Q010 only for the remaining-M004 deadline. Q013 remains
  consumed; historical envelopes, reports and prior ledger bytes remain intact.
  All other limits and qualification exclusions are unchanged.
