# Question: calibrate the remaining M002 full-verification deadline

Status: answered

- Date asked: 2026-09-14
- Owner or likely answerer: project owner.
- What one question needs an answer? Authorize a 900-second whole-command
  verification deadline for the remaining M002 gates, including the retained
  S05 candidate and subsequent S03 verification, while retaining every other
  acceptance requirement and existing cumulative work allowance?
- Why does it block or affect the slice? S05 round 1 authoritatively timed out
  at 600.004 seconds. The first corrective round made a small Windows bootstrap
  improvement and preserved the probe and process protections, but authoritative
  round 2 also timed out, at 600.008 seconds with 366 completion dots from 620
  discovered tests. Both workspace witnesses were stable. No authoritative
  full-command pass exists. S05 is now in corrective round 3; S03 remains blocked
  pending S05 acceptance. No new coding prompt or verification is issued while
  this budget question is pending.
- Current guess, explicitly not authority: 900 seconds gives a measurable
  50 percent increase without requiring speculative process changes merely to
  fit the original baseline-era limit. It is not a prediction or a guarantee of
  completion. The coder observed all 620 tests pass in 598.20 pytest seconds,
  followed by enclosing timeout at 600.014 seconds; the architect did not
  reproduce that completion. Timing variation remains unexplained, and test
  progress counts must not be extrapolated linearly to total duration.

## Concrete proposal

- Keep the current product candidate, full test command, test discovery,
  unexpected-skip refusal, workspace witnesses and process ownership safeguards.
  Do not remove tests, cache witnesses across probes or bypass managed execution.
- If authorized, record the owner's decision prospectively. Use the new budget
  in S05's next corrective envelope and explicitly apply the same deadline-only
  exception to remaining M002 verification, including S03's frozen 600-second
  policy. Preserve historical envelopes, ledger events and failed receipts;
  document the actual timeout used beside future verification evidence. The
  exception must not be presented as compliance with the old 600-second gate.
- Do not expand code scope, model/experiment allowances, number of corrective
  rounds or cumulative M002 36 invocations/360 active minutes. A new budget
  permits verification, not acceptance, a code rewrite, publication or a commit.
- First reverify the retained candidate under the authorized policy. Independent
  review still follows only a successful authoritative full-command result.
  If the new limit also fails, preserve its receipt and stop for reassessment.
- If declined, retain the current 600-second gate and obtain a concrete bounded
  alternative before spending the last corrective round. No further speculative
  product optimization is currently requested.

## Evidence

- `05_governance/reviews/m002/M002-S05_r1_verification.json`
- `05_governance/reviews/m002/M002-S05_r1_timing_assessment.md`
- `05_governance/reviews/m002/M002-S05_r2_coder_notes.md`
- `05_governance/reviews/m002/M002-S05_r2_verification.json`
- `05_governance/reviews/m002/M002-S05_r2_manifest_39f6579d305a6837.json`

## Answer

- Answered by: project owner; explicit approval in this task.
- Date answered: 2026-09-14
- Answer: Approved. Continue with the retained candidate under the proposed 900-second deadline for the remaining M002 gates; all other requirements and cumulative allowances remain.
- Decision or roadmap artifact updated: D018 and roadmap.yaml. Historical 600-second envelopes and failed receipts remain unchanged. The answered authority supersedes only that deadline for remaining M002 verification.
