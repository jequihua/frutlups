# Question: calibrate the M004 verification deadline

Status: answered

- Date asked: 2026-09-16.
- Owner or likely answerer: project owner.
- What one question needs an answer? Approve a 1200-second full-verification
  deadline for the remainder of M004, starting with one authoritative attempt
  on the unchanged round-3 corrected candidate, or retain 900 seconds and
  separately admit a bounded optimization first?
- Why does it block or affect the slice? The round-3 coder full command
  discovered 936 tests but timed out at 900.003 seconds without a final pytest
  summary. Full success and zero unexpected skips remain unverified. The
  ledger records M004-S01 round 3 blocked_authority. Q009 requires stopping
  after failure/timeout and grants no optimization or longer deadline;
  Q008's earlier one-attempt 1200-second exception is consumed.
- Current guess, explicitly not authority: approve 1200 seconds for M004's
  remaining full verification, then verify this retained candidate once and
  proceed to independent review only if it passes. This provides headroom
  for the measured suite without mixing an unreviewed optimization into S01.
  It is not a completion guarantee, performance improvement or production
  latency claim. Repeated one-off deadline negotiations add development work
  without improving the correctness gate.

## Concrete proposed authority

- Change only M004's full-verification deadline to 1200 seconds, expiring at
  M004 closure when 600 is restored. Existing frozen envelopes/receipts retain
  their historical 900-second text; new execution/review explicitly cites
  this authority if approved. Future admitted envelopes use the new deadline.
- Next move: architect resolves the typed blocker with this answered authority,
  binds the unchanged round-3 manifest and runs the full verifier once with
  timeout 1200. No coder, focused suite or profile is repeated for that move.
  Failure/timeout stops for reassessment; no automatic further extension.
- No reduction in discovery, assertions, skip policy, evidence stability,
  managed child ownership or independent review. All other round, seat,
  active-time and spend limits retain prior consumption; missing totals stay
  unknown. Resolution/verification does not replenish corrective coding.
- No optimization, public /2 enablement, provider call, commit or next-slice
  admission is granted by changing the deadline. The measured immutable
  tree/blob batching candidate remains advisory backlog work.

## Evidence

- 05_governance/reviews/m004/M004-S01_r3_coder_notes.md, SHA-256
  833b006db19e6da97c2e3a9ae81a5211f4481ff1b80b659d5614d11322696692:
  attributed coder report, original external-source hashes, portable process
  result and complete captured stdout. The child result's exit 0 is not success:
  timed_out is true and the test summary is absent. No authoritative full
  receipt or stable before/after full-run witness is invented from this output.
- 05_governance/reviews/m004/M004-S01_r3_manifest_8ee230ad3060db32.json,
  SHA-256 8ee230ad3060db32856c20e679ee234cc747df6175485d35be37e95d96d57ca2.
- 05_governance/reviews/m004/M004-S01_r3_outcome_199bbb2ba32c7a00.json,
  SHA-256 199bbb2ba32c7a009436b22be752d9a8e48376cbf3ae21b3ef8a1a61adf4f857.
- Focused 279 passes in 368.15 seconds; two profiles passed in 32.683435
  enclosing seconds total. Four approval/recovery cases used 331 managed Git
  launches / 20.947206 cumulative seconds within 26.114203 enclosing seconds.
  Overlapping cumulative times are not additive; these profiles do not
  establish production latency, child CPU costs or a safe optimization.

## Answer

- Answered by: project owner, explicit approval in this task.
- Date answered: 2026-09-16.
- Answer: Approved 1200 seconds for the remainder of M004, starting with one
  authoritative run of the retained corrected candidate. All other limits
  remain unchanged; restore 600 seconds at M004 closure.
- Updated authority: this answered Q010 and roadmap verification.timeout_seconds.
  Historical frozen 900-second acceptance and Q007 text remain historical;
  execution and independent review must cite Q010 for the new deadline.
  The prior resolution binds decisions.md byte-for-byte, so that register and
  all prior ledger bytes remain unchanged. No broader authority is inferred.
