# Method

Progress is an artifact becoming more explicit, reviewable, or correct. Agent
activity is not evidence by itself.

## Authorities

- `roadmap.yaml`: milestones, slices, acceptance, verification, risk, and write
  boundaries.
- `05_governance/ledger.jsonl`: append-only loop events and derived state.
- `00_brief/decisions.md`: accepted project decisions.
- `questions/`: durable blockers and their answers.

`docs/roadmap.md`, status/index output, prompts, coder notes, and review prose
are views or evidence. They do not replace their authority source.

## Roles

The human owner controls destination, priorities, waivers, external effects,
and stop/go decisions. The architect translates that authority into brief and
roadmap entries, runs the loop scripts, saves manual outputs, records reviews,
accepts slices, and makes authorized acceptance commits. The coder changes only
the prompt's product boundary and reports facts. Review is product-read-only;
manual reviewers may write only their named report, while autonomous reviewers
return it for frutlups to save. frutlups may perform the architect's mechanical
handoffs but receives no broader authority.

## One slice

1. The architect renders a coding prompt. Its successful write and hash are
   followed by a `prompt` event.
2. The coder implements within the effective prefixes, runs focused checks, and
   returns factual notes. Git—not those notes—produces the changed-file list.
3. The architect records `coded`. An out-of-bound change refuses the event and
   leaves the tree for a human; nothing is reverted automatically.
4. `verify.py` runs the declared full argv and writes a receipt. It appends
   `verified` whether the check passes or fails.
5. On success, a review prompt carries the receipt, cumulative changed-path
   manifest, current-round bounded diff, and optional notes to a read-only
   reviewer. A neutral `artifact` event records its immutable identity without
   changing lifecycle state.
6. `ledger.py record` validates the report and appends `reviewed`.
7. A pass becomes `accept_pending`. The architect accepts it, optionally making
   the exact acceptance commit. Needs-work or failed verification produces a
   new corrective round; blocked stops for the named owner. A human or architect
   records `/2` `resolved` with a reason and bound authority to start the next
   corrective round, preserving the blocker.

Manual and compatible autonomous operation share these files and transitions.
This `/2` candidate is manual-ready; paired conformance and mode switching still
require qualification. Old runners refuse its roadmap. Follow `docs/upgrading.md`
before transferring ownership, including pending attempts or Git operations.

## Acceptance envelope

Review against the slice objective, acceptance list, non-goals, read/write
boundary, and verification contract plus repository safety rules. A reviewer
does not enlarge the envelope. A newly desired property becomes a proposed
roadmap change, not an in-place blocking demand.

Findings have stable ids, severity, disposition, and summary:

- P0: imminent safety, credential, destructive-authority, or data-loss risk.
- P1: incorrect behavior, broken required contract, or material architecture
  error; must be fixed before pass.
- P2: material bounded defect in evidence, compatibility, or maintainability;
  must be fixed before pass unless a human waives the exact finding.
- P3: clarity or deferred hardening that cannot falsely authorize acceptance;
  it may be carried to `backlog.md` with a pass.

The reviewer opens and closes findings. A coder may remediate or challenge but
never self-close. Only the human owner records `waived_by_human`. A report with
open P0-P2 cannot pass. Uncertain materiality remains P2 until reviewed.

## Objective and verdict

The closure decision independently records whether the stated objective is
`achieved`, `not_achieved`, or `indeterminate`, with one evidence sentence. The
verdict judges the implementation against its envelope: `pass`, `needs_work`,
or `blocked`. A truthful stopped experiment can pass its implementation contract
while its objective remains not achieved; that does not claim research success.

The report contains one final section and one line:

```text
## Verdict
Verdict: pass|needs_work|blocked - next: <one move>
```

Human records may additionally use `override`; autonomous reviewers may not.

## Rounds and reopening

Rounds start at 1. Failed verification, a needs-work review, or an authorized
resolution advances the next coding prompt to the following round and carries
the relevant command tails, open findings, and resolution reason. The prompt
automatically baselines exact ledger-known same-slice state; `--allow-dirty` is
reserved for inspected unknown architect state. Transport failure may use only
a declared retry allowance; an unresolved prior invocation blocks new work.
A retry does not consume a corrective round. Review later rounds against open findings, the delta,
and evidence invalidated by that delta.

After a blocker is resolved, the next round preserves its original frozen
acceptance envelope. Ordinary needs-work rounds read the admitted roadmap when
issued. Material respecification after a blocker belongs in a new slice; editing
roadmap acceptance cannot replace the blocked round's original contract.

An accepted slice may be reopened only by a human or architect record with a
reason. Append `reopened` at the next round; never edit the earlier pass or
acceptance.

## Milestones

Roadmap status remains `planned`, `active`, or `done`; zero active milestones are
valid with nonempty milestones/slices and the existing shape rules. The architect
marks done status; that label creates neither acceptance nor a `milestone_done`
event. Status reports no active milestone as a planning fact, never project success.
Reopened work and pending-operation diagnostics remain visible. Manual selection
stays explicit; no work is automatically activated.

Preserving a superseded planned/blocked milestone is supported for manual history
without a grant for that milestone, including autonomy projects whose superseded
milestone never had a run. Q001 requires any ever-admitted milestone to stay active
or be provably completed done with settled attempts; closed/superseded/overrun runs
cannot become planned. Manual operation does not erase that restriction. Keep the
active marker and record a supersession decision without granting new dispatch or
allowance. Completed admitted done plus never-admitted planned work can have no
active milestone. General retirement of unfinished admitted work is excluded.
Next-slice selection prioritizes reopened work, then scans active milestones
in order, skipping those whose slices are all accepted. It does not activate
planned milestones or require holistic completion before considering the next
active milestone. The rendered roadmap displays each declared status.

A milestone's slices are accepted only through the ledger. If
`holistic_review: false`, all accepted slices make it done without a
`milestone_done` event. If true, a holistic review must pass before that event
is recorded. A holistic P0-P2 finding id starts with the affected slice id. All
open findings for one slice produce one reopen reason containing every id; then
continue that slice's round sequence. Holistic prompt/report artifact events
preserve provenance across that reopen. Empty work or an empty next frontier is
not completion.

## Commits

Coders never commit unless the owner explicitly changes that rule. In `/2`,
`ledger.py accept <slice>` records ledger-only approval. With authorized
`--commit`, that same append binds the exact payload, parent and operation intent.
Other writes freeze until Git completion or attributed cancellation. A commit
proves completion through its validated `Template-Operation:` witness; no second
approval or completion append dirties the ledger. Interrupted work uses
`ledger.py recover`, then `recover --execute` for only its missing Git work.
Neither command pushes.

Ledger-only acceptance requires inspected manual housekeeping commits before a
new slice starts. Owner hotfixes committed after acceptance may match HEAD for
holistic review/close; they do not change what the earlier review approved.
Active review and acceptance remain pinned to the exact verified candidate.

Before committing, require passing verification and review, inspect status,
exclude secrets/local state, and inspect the exact staged paths. Pull requests,
front-repository publication, tags, and pushes require separate human authority.

## Planning uncertainty

`not_yet_specified` holds plausibly in-scope concerns not sharp enough to be a
slice or precise question. `ruled_out` holds accepted project exclusions. They
never enter the ready frontier. Sharp externally blocked work belongs in
`questions/open/`; do not hide it as uncertainty. Changing the project
destination or resurrecting a ruled-out item needs human approval.
