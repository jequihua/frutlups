"""Review grammar and Git evidence shared by prompt and ledger commands."""

from __future__ import annotations

import json
import re
from pathlib import Path

import _common as c

DIFF_LIMIT = 32 * 1024
HOLISTIC_STAT_LIMIT = 4 * 1024
HOLISTIC_PATH_LIMIT = 64


def bounded_text(text, rel, limit=4096, *, digest=None):
    raw = text.encode("utf-8")
    if len(raw) <= limit:
        return text
    if not digest:
        raise ValueError("truncated artifact requires its complete SHA-256: " + rel)
    clipped = raw[:limit].decode("utf-8", "ignore")
    reference = f"`{rel}` (sha256 `{digest}`)"
    return clipped + f"\n\n[Embedded text truncated; read the full artifact at {reference}.]"


def read_excerpt(root, rel, limit=4096):
    """Read at most the requested UTF-8 prefix, never a whole bulk artifact."""
    path = c.repo_path(root, c.safe_rel(rel))
    if path.is_symlink() or not path.is_file():
        raise ValueError(f"not a regular repository file: {rel}")
    with path.open("rb") as stream:
        raw = stream.read(limit + 1)
    text = raw.decode("utf-8", "replace")
    return bounded_text(
        text,
        rel,
        limit,
        digest=c.sha(path) if len(text.encode("utf-8")) > limit else None,
    )


def _visible_lines(text):
    output = []
    fence = None
    for line in text.splitlines():
        mark = re.match(r"^\s*(`{3,}|~{3,})", line)
        if mark:
            token = mark.group(1)[0]
            fence = token if fence is None else None if fence == token else fence
            continue
        if fence is None:
            output.append(line)
    return output


def parse_review(text):
    lines = _visible_lines(text)
    names = ("## Findings", "## Closure Decision", "## Verdict")
    headings = {
        name: [index for index, line in enumerate(lines) if line.strip() == name] for name in names
    }
    if any(len(found) != 1 for found in headings.values()):
        raise ValueError(
            "review requires exactly one Findings, Closure Decision, and Verdict heading"
        )
    findings_at, closure_at, verdict_at = (headings[name][0] for name in names)
    if not findings_at < closure_at < verdict_at:
        raise ValueError("review sections are out of order")
    title_pattern = r"# Review: M\d{3}(?:-S\d{2})? round (?:\d+|holistic)"
    title = next(
        (line for line in lines[:findings_at] if re.fullmatch(title_pattern, line.strip())),
        None,
    )
    if not title:
        raise ValueError("review title is missing or invalid")
    match = re.fullmatch(r"# Review: (M\d{3}(?:-S\d{2})?) round (\d+|holistic)", title.strip())
    identity, round_text = match.groups()
    updates_at = next(
        (i for i in range(findings_at + 1, closure_at) if lines[i].strip() == "## Finding updates"),
        closure_at,
    )
    table = [line for line in lines[findings_at + 1 : updates_at] if line.strip().startswith("|")]
    header = _cells(table[0]) if table else []
    separator = _cells(table[1]) if len(table) > 1 else []
    if header != ["id", "severity", "disposition", "summary"]:
        raise ValueError("findings table header or separator is missing")
    if not separator or not all(set(item) <= {"-", ":"} for item in separator):
        raise ValueError("findings table header or separator is missing")
    findings = []
    seen = set()
    for line in table[2:]:
        cells = _cells(line)
        if len(cells) == 4 and all(set(item) <= {"-", ":"} for item in cells):
            continue
        valid = (
            len(cells) == 4
            and cells[0] not in seen
            and cells[1] in ("P0", "P1", "P2", "P3")
            and cells[2] in ("open", "closed_by_review", "carried", "waived_by_human")
            and bool(cells[0])
            and bool(cells[3])
        )
        if not valid:
            raise ValueError(f"invalid findings row: {line.strip()}")
        seen.add(cells[0])
        findings.append(dict(zip(("id", "severity", "disposition", "summary"), cells)))
    closure = [line.strip() for line in lines[closure_at + 1 : verdict_at] if line.strip()]
    statuses = [
        line.removeprefix("Objective status: ")
        for line in closure
        if line.startswith("Objective status: ")
    ]
    evidence = [
        line.removeprefix("Objective evidence: ")
        for line in closure
        if line.startswith("Objective evidence: ")
    ]
    valid = (
        len(statuses) == 1
        and statuses[0] in ("achieved", "not_achieved", "indeterminate")
        and len(evidence) == 1
        and bool(evidence[0])
    )
    if not valid:
        raise ValueError("invalid closure decision")
    verdict_lines = [line.strip() for line in lines[verdict_at + 1 :] if line.strip()]
    verdict_match = (
        re.fullmatch(
            r"Verdict: (pass|needs_work|blocked|override) - next: (.+)",
            verdict_lines[0],
        )
        if verdict_lines
        else None
    )
    if not verdict_match or any(line.startswith("Verdict:") for line in verdict_lines[1:]):
        raise ValueError("invalid verdict line")
    verdict, move = verdict_match.groups()
    open_ids = [
        item["id"]
        for item in findings
        if item["severity"] in ("P0", "P1", "P2") and item["disposition"] == "open"
    ]
    if verdict in ("pass", "override") and open_ids:
        raise ValueError(f"{verdict} cannot have open P0-P2 findings")
    return {
        "identity": identity,
        "round": None if round_text == "holistic" else int(round_text),
        "findings": findings,
        "objective_status": statuses[0],
        "objective_evidence": evidence[0],
        "verdict": verdict,
        "next_move": move,
        "open": open_ids,
    }


def _cells(line):
    row = re.sub(r"^\||(?<!\\)\|$", "", line.strip())
    cells = [item.strip().replace(r"\|", "|") for item in re.split(r"(?<!\\)\|", row)]
    return cells[:3] + [" | ".join(cells[3:])] if len(cells) > 4 else cells


def changed_files(root):
    records = c.status_bytes(root).split(b"\0")
    output = []
    index = 0
    while index < len(records) and records[index]:
        record = records[index].decode("utf-8", "surrogateescape")
        code = record[:2]
        rel = record[3:].replace("\\", "/")
        index += 1
        if "R" in code:
            kind = "renamed"
        elif "D" in code:
            kind = "deleted"
        elif code == "??" or "A" in code:
            kind = "added"
        else:
            kind = "modified"
        if kind == "renamed" and index < len(records):
            index += 1
        path = c.repo_path(root, c.safe_rel(rel))
        if path.is_symlink():
            raise ValueError(f"changed path is a symlink: {rel}")
        if kind == "deleted":
            digest = None
        elif path.is_file():
            digest = c.sha(path)
        else:
            raise ValueError(f"changed path is not a regular file: {rel}")
        output.append({"path": rel, "sha": digest, "kind": kind})
    deleted = head_shas(root, [row["path"] for row in output if row["kind"] == "deleted"])
    for row in output:
        if row["kind"] == "deleted":
            row["sha"] = deleted[row["path"]]
            if row["sha"] is None:
                raise ValueError("deleted path has no HEAD blob: " + row["path"])
    return output


def head_shas(root, paths):
    """Batch normalized HEAD blob hashes; None means no blob at that exact path."""
    import _commit
    import _git as gitops

    paths = list(dict.fromkeys(c.safe_rel(path) for path in paths))
    if not paths:
        return {}
    result = gitops.run(root, "rev-parse", "--verify", "HEAD^{commit}", limit=1024, check=False)
    if result.returncode:
        branch = gitops.run(root, "symbolic-ref", "-q", "HEAD", limit=1024).stdout.decode().strip()
        if (
            branch.startswith("refs/heads/")
            and gitops.run(
                root, "show-ref", "--verify", "--quiet", branch, check=False, limit=1024
            ).returncode
            == 1
        ):
            return dict.fromkeys(paths)
        raise ValueError("HEAD is neither an available commit nor an unborn branch")
    tree = _commit._tree(root, result.stdout.decode("ascii").strip())
    selected = {path: tree[path][2] for path in paths if path in tree}
    if any(tree[path][1] != "blob" for path in selected):
        raise ValueError("commit content is not an available blob")
    hashes = gitops.blob_hashes(root, selected.values())
    return {
        path: hashes[selected[path]]["normalized"] if path in selected else None for path in paths
    }


def head_sha(root, rel):
    return head_shas(root, [rel])[rel]


def matches_head(root, rel, *, heads=None):
    """Whether the current regular file or absence is identical to HEAD."""
    path = c.repo_path(root, c.safe_rel(rel))
    if path.is_symlink():
        return False
    digest = head_sha(root, rel) if heads is None else heads[rel]
    if digest is None:
        return not path.exists()
    return path.is_file() and c.sha(path) == digest


def _known_baseline_paths(events, sid):
    import _protocol as protocol

    paths = {"05_governance/ledger.jsonl", "05_governance/backlog.md", "docs/roadmap.md"}
    milestone = sid.split("-")[0]
    for index, event in enumerate(events):
        belongs = event.get("slice") == sid or event.get("scope") == sid
        if event.get("scope", event.get("milestone")) == milestone:
            belongs = any(
                later["ev"] == "reopened"
                and later.get("slice") == sid
                or later["ev"] == "holistic_reviewed"
                and any(finding.startswith(sid + "-") for finding in later["open"])
                for later in events[index:]
            )
        if belongs:
            paths.update(
                event[key] for key in ("path", "receipt", "report", "notes_path") if event.get(key)
            )
            paths.update(ref["path"] for ref in protocol.event_references(event))
    return paths


def prompt_baseline(root, rm, events, sid, allow_dirty=False, prospective=()):
    slice_ids = {item["id"] for milestone in rm["milestones"] for item in milestone["slices"]}
    if sid not in slice_ids:
        raise ValueError(f"unknown slice: {sid}")
    changed = changed_files(root)
    known_paths = _known_baseline_paths(events, sid) | set(prospective)
    products = {
        (item["path"], item["sha"], item["kind"])
        for event in events
        if event["ev"] == "coded" and event["slice"] == sid
        for item in event["changed"]
    }
    unexplained = [
        row
        for row in changed
        if row["path"] not in known_paths and (row["path"], row["sha"], row["kind"]) not in products
    ]
    heads = head_shas(
        root,
        [row["path"] for row in unexplained if not c.repo_path(root, row["path"]).is_symlink()],
    )
    unknown = [row for row in unexplained if not matches_head(root, row["path"], heads=heads)]
    if unknown and not allow_dirty:
        paths = ", ".join(item["path"] for item in unknown)
        raise ValueError(
            "unknown dirty paths must be committed or stashed: "
            f"{paths}; inspect them before using --allow-dirty"
        )
    return changed


def fence(changed, allowed, forbidden):
    def matches(path, rule):
        return path.startswith(rule) if rule.endswith("/") else path == rule

    return [
        item["path"]
        for item in changed
        if any(matches(item["path"], rule) for rule in forbidden)
        or not any(matches(item["path"], rule) for rule in allowed)
    ]


def rel_file(root, value):
    rel = c.cli_rel(value)
    path = c.repo_path(root, rel)
    if not path.is_file() or path.is_symlink():
        raise ValueError(f"not a regular repository file: {rel}")
    return rel, path


def diff_block(text, paths, limit=DIFF_LIMIT):
    notice = "\n[Diff truncated at 32 KB; read the named files and complete manifest.]"
    raw = text.encode("utf-8")
    if len(raw) > limit:
        room = max(0, limit - len(notice.encode("utf-8")))
        text = raw[:room].decode("utf-8", "ignore").rstrip() + notice
    if not text.strip():
        text = "(no textual diff; inspect " + ", ".join(paths[:8]) + ")"
    return "```diff\n" + text.rstrip() + "\n```"


def selected_changes(changed):
    """Prioritize source/config/tests before selecting a bounded evidence window."""
    source = {
        ".py",
        ".js",
        ".ts",
        ".tsx",
        ".jsx",
        ".go",
        ".rs",
        ".java",
        ".sh",
        ".c",
        ".h",
        ".cpp",
        ".hpp",
        ".sql",
    }
    config = {".toml", ".yaml", ".yml", ".json", ".ini", ".cfg", ".md", ".css", ".html"}

    def priority(item):
        path = item["path"]
        suffix = Path(path).suffix.lower()
        generated = any(
            re.sub(r"^\d+_", "", part) in ("generated", "artifacts", "outputs", "fixtures", "data")
            for part in path.lower().split("/")[:-1]
        )
        rank = 0 if suffix in source else 1 if suffix in config else 2
        return (3 if generated and rank else rank, path)

    return sorted(changed, key=priority)[:HOLISTIC_PATH_LIMIT]


def review_diff(root, changed, limit=DIFF_LIMIT):
    import _git as gitops

    selected = selected_changes(changed)
    paths = [item["path"] for item in selected]
    if not paths:
        return diff_block("(no product changes)", paths, limit)
    parts = ["HEAD diff filtered to current-round paths; this is not a prior-round delta.\n"]
    remaining = max(0, limit - 512 - len(parts[0].encode("utf-8")))
    # Bound each source separately, so one generated or unusually large file
    # cannot consume the evidence window before the next relevant source.
    for item in selected:
        if remaining < 256:
            break
        per_file = min(4096, remaining)
        body = gitops.bounded_diff(root, "HEAD", [item["path"]], per_file)
        if not body and item["kind"] == "added":
            excerpt = read_excerpt(root, item["path"], max(128, per_file - 160))
            if "\0" in excerpt:
                excerpt = "[Binary artifact; use its manifest identity and named file.]"
            body = f"\nAdded file: {item['path']}\n" + excerpt
        parts.append(body)
        remaining -= len(body.encode("utf-8"))
    if len(selected) < len(changed) or remaining < 256:
        parts.append("\nEvidence window bounded; all paths remain in the complete manifest.")
    if any("truncated" in part.lower() for part in parts):
        parts.append("\nDiff truncated at 32 KB or the smaller per-file evidence allowance.")
    return diff_block("".join(parts), paths, limit)


def slice_changes(events, sid):
    """Return stable first-seen paths with their most recent coded metadata."""
    latest = {}
    for event in events:
        if event["ev"] != "coded" or event["slice"] != sid:
            continue
        for item in event["changed"]:
            latest[item["path"]] = {**item, "round": event["round"]}
    return list(latest.values())


def holistic_diff(root, base, paths_by_slice, limit=DIFF_LIMIT):
    import _git as gitops

    all_paths = list(dict.fromkeys(path for paths in paths_by_slice.values() for path in paths))
    selected = [item["path"] for item in selected_changes([{"path": p} for p in all_paths])]
    stat = gitops.bounded_diff(root, f"{base}..HEAD", selected, HOLISTIC_STAT_LIMIT, stat=True)
    indexed = set(gitops.run(root, "ls-files", "-z").stdout.split(b"\0"))
    heading = f"git diff {base}..HEAD --stat (selected paths)\n{stat}"
    if not stat.strip():
        heading += (
            "\nNo committed changes in this selected range. Ledger-only accepted work may "
            "remain in the working tree; the bounded per-slice evidence below includes it."
        )
    if len(all_paths) > HOLISTIC_PATH_LIMIT:
        heading += "\nBulk detail omitted by the bounded evidence gate; source detail follows."
    sections = []
    remaining = max(0, limit - len(heading.encode("utf-8")) - 512)
    for rel in selected:
        if remaining < 256:
            break
        sid = next(sid for sid, paths in paths_by_slice.items() if rel in paths)
        # Compare the accepted current worktree to the first accepted base. This
        # includes committed and ledger-only edits, in global source-first order.
        per_file = min(4096, remaining - 128)
        body = gitops.bounded_diff(root, base, [rel], per_file)
        if not body and rel.encode("utf-8") not in indexed and (root / rel).is_file():
            excerpt = read_excerpt(root, rel, max(128, per_file - 256))
            if "\0" in excerpt:
                excerpt = "[Binary artifact; inspect its manifest identity and named file.]"
            body = f"\nAdded file: {rel}\n" + excerpt
        if not body:
            body = f"No textual change against the accepted base for {rel}."
        section = f"\n### {sid}\n\n{body.rstrip()}"
        sections.append(section)
        remaining -= len(section.encode("utf-8"))
    heading += (
        "\nPer-slice diffs: current working tree against accepted base "
        "(bounded; complete manifests remain authoritative)."
    )
    return diff_block(heading + "".join(sections), all_paths, limit)


def accepted_base(root, events, milestone):
    import _git as gitops

    ids = {item["id"] for item in milestone["slices"]}
    for index, event in enumerate(events):
        if event["ev"] != "accepted" or event["slice"] not in ids:
            continue
        verified = next(
            (
                old
                for old in reversed(events[:index])
                if old["ev"] == "verified"
                and old["slice"] == event["slice"]
                and old["round"] == event["round"]
                and old["ok"]
            ),
            None,
        )
        if not verified:
            break
        receipt = json.loads((root / verified["receipt"]).read_text(encoding="utf-8"))
        base = receipt.get("base_commit")
        valid = (
            isinstance(base, str)
            and re.fullmatch(r"[a-f0-9]{40}|[a-f0-9]{64}", base)
            and gitops.run(
                root, "cat-file", "-e", base + "^{commit}", limit=1024, check=False
            ).returncode
            == 0
        )
        if valid:
            return base
        break
    raise ValueError("cannot resolve the first accepted base commit for holistic review")


def findings_context(root, state, events=None, sid=None):
    prefix = ""
    if state.get("unblock_reason"):
        prefix = f"Unblock reason: {state['unblock_reason']}\n\n"
    if events is not None and sid:
        import _findings as findings

        projected, _ = findings.project(root, events)
        rows = []
        for (path, sha, identity), item in projected.items():
            if item["disposition"] not in ("open", "carried") or not (
                item["owner"] == sid or identity.startswith(sid + "-")
            ):
                continue
            rows.append(
                f"Source review: `{path}` (sha256 `{sha}`)\n"
                f"| {identity} | {item['severity']} | {item['disposition']} | {item['summary']} |"
            )
        if rows:
            return prefix + "\n\n".join(rows)
    if state["open"] and state["report"]:
        report = parse_review((root / state["report"]).read_text(encoding="utf-8"))
        rows = [
            f"| {item['id']} | {item['severity']} | {item['disposition']} | {item['summary']} |"
            for item in report["findings"]
            if item["id"] in state["open"]
        ]
        source = f"Source review: `{state['report']}` (sha256 `{c.sha(root / state['report'])}`)"
        return prefix + source + "\n\n" + "\n".join(rows)
    if state["receipt"]:
        receipt = json.loads((root / state["receipt"]).read_text(encoding="utf-8"))
        if not receipt["ok"]:
            command = receipt["commands"][-1]
            return (
                prefix + "Previous verification failed. Complete receipt: "
                f"`{state['receipt']}` (sha256 `{c.sha(root / state['receipt'])}`)"
                "\n\nstdout tail:\n```text\n"
                f"{command['stdout_tail']}\n```\n\nstderr tail:\n```text\n"
                f"{command['stderr_tail']}\n```"
            )
    return prefix.rstrip()
