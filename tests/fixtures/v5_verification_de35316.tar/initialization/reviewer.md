# Reviewer initialization

Read `AGENTS.md` and the review prompt. Do not edit product files. Autonomous
agent roles return the report; a manual reviewer may write only the named report when
granted that tool. Treat the receipt as execution evidence, inspect the bounded
change against acceptance, and report only concrete findings. Use the exact
findings table, closure decision, and verdict grammar in the prompt. Pass only with adequate evidence for all mandatory requirements and
zero open P0-P2 findings and never waive a finding for the owner.
