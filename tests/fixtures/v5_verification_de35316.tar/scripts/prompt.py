"""Render complete agent envelopes with bounded, immutable review evidence."""

import argparse
import json
import re
import sys
from pathlib import Path

import _common as c
import _evidence as evidence
import _integrity as integrity
import ledger
import roadmap

CODING_LIMIT, REVIEW_LIMIT = 16 * 1024, 48 * 1024
KNOWN = {
    "slice_id",
    "title",
    "round",
    "objective",
    "acceptance",
    "non_goals",
    "read_first",
    "allowed_prefixes",
    "forbidden",
    "focused",
    "full",
    "open_findings",
    "memory",
    "diff_manifest",
    "diff_evidence",
    "coder_notes",
    "receipt",
    "prior_findings",
    "report_path",
    "finding_id_rule",
    "finding_updates",
    "notes",
    "outcome_contract",
}
ENVELOPE_SECTIONS = (
    ("Objective", "objective"),
    ("Acceptance", "acceptance"),
    ("Non-goals", "non_goals"),
    ("Read first", "read_first"),
    ("Allowed writes", "allowed_prefixes"),
    ("Forbidden writes", "forbidden"),
    ("Focused verification", "focused"),
    ("Full verification", "full"),
    ("Advisory notes", "notes"),
    ("Findings and resolutions", "open_findings"),
    ("Memory", "memory"),
)
REVIEW_SECTIONS = (
    ("Changed files", "diff_manifest"),
    ("Code diff", "diff_evidence"),
    ("Coder notes", "coder_notes"),
    ("Verification receipt", "receipt"),
    ("Prior findings", "prior_findings"),
    ("Report destination", "report_path"),
    ("Finding IDs", "finding_id_rule"),
    ("Finding reconciliation", "finding_updates"),
)


def _bullets(values, empty="- None declared."):
    return "\n".join(f"- {value}" for value in values) if values else empty


def _argv(values):
    if not values:
        return "- None declared."
    commands = [values] if isinstance(values[0], str) else values
    return "\n\n".join("```text\n" + " ".join(command) + "\n```" for command in commands)


def _render(
    path, values, optional=(), complete=False, *, limit=REVIEW_LIMIT, diagnose=True, inapplicable=()
):
    if path.stat().st_size > limit:
        raise ValueError(f"template framing exceeds {limit} bytes; reduce the custom template")
    text = evidence.read_excerpt(path.parent, path.name, limit + 1).replace("\r\n", "\n")
    found = set(re.findall(r"{{([a-z_]+)}}", text))
    unknown = found - KNOWN
    if unknown:
        raise ValueError(f"unknown placeholders: {sorted(unknown)}")
    bare = re.sub(r"{{[a-z_]+}}", "", text)
    if "{{" in bare or "}}" in bare:
        raise ValueError("unresolved placeholder")
    for heading, key in optional:
        if not values.get(key):
            pattern = rf"\n## {re.escape(heading)}\n.*?(?=\n## |\Z)"
            text = re.sub(pattern, "", text, flags=re.DOTALL)
    if diagnose:
        for key in sorted(set(re.findall(r"{{([a-z_]+)}}", text))):
            if not values.get(key) and key not in inapplicable:
                print(f"diagnostic: template renders empty {key}", file=sys.stderr)
    text = re.sub(r"{{([a-z_]+)}}", lambda match: str(values.get(match[1], "")), text)
    # Preserve project-owned templates while making omitted authority visible.
    additions = ENVELOPE_SECTIONS if complete else (("Advisory notes", "notes"),)
    if complete:
        additions += (("Task", "slice_id"), ("Title", "title"), ("Round", "round"))
    if complete and "report_path" in values:
        additions += REVIEW_SECTIONS
    for heading, key in additions:
        if key not in found and values.get(key):
            if diagnose:
                print(
                    f"diagnostic: custom template omitted {key}; appended its full section",
                    file=sys.stderr,
                )
            text += f"\n\n## {heading}\n\n{values[key]}"
    if (
        complete
        and "report_path" in values
        and not all(marker in bare for marker in ("# Review:", "## Closure Decision", "## Verdict"))
    ):
        text += "\n\n## Required report contract\n\n" + _report_contract(values)
    if values.get("outcome_contract") and "outcome_contract" not in found:
        if diagnose:
            print(
                "diagnostic: custom template omitted outcome_contract; appended its full section",
                file=sys.stderr,
            )
        text += "\n\n## Autonomous outcome\n\n" + values["outcome_contract"]
    if diagnose:
        handled = {key for _, key in additions} | {"outcome_contract"}
        for key in sorted(values.keys() & KNOWN - found - handled):
            if values[key]:
                print(f"diagnostic: custom template omitted {key}", file=sys.stderr)
    if complete:
        text += (
            "\n\n## Evidence hash rule\n\n"
            "`sha` in change manifests and bound artifact references means normalized evidence "
            "SHA-256: replace CRLF with LF only if no NUL occurs anywhere; preserve lone CR. "
            "With any NUL, hash all bytes unchanged. Exact-byte archives require raw SHA-256 "
            "and raw byte size. Embedded receipt witness/index/product digests keep their "
            "own meanings."
        )
    return text.replace("\r\n", "\n").rstrip() + "\n"


def _report_contract(values):
    return (
        "Review is product-read-only. In manual mode write only `"
        + values["report_path"]
        + "` if granted, or return the report for the architect to save. Autonomous seats "
        "return the complete report. Use this exact shape as plain final text, choosing one "
        "value on each choice line. Each P0-P2 summary identifies obligation, location, "
        "conditions, evidence or argument, and material consequence. Distinguish an observed "
        "defect from a missing demonstration; present maintainability costs count, hypothetical "
        "flexibility and preferences do not. Pass requires adequate evidence for every "
        "mandatory frozen-contract requirement and zero open P0-P2. Otherwise use needs_work or "
        "blocked. Record objective outcome independently: a predeclared trial may pass "
        "execution/reporting with a negative or indeterminate result; a missing required CLI "
        "cannot pass.\n\n```markdown\n"
        + f"# Review: {values['slice_id']} round {values['round']}\n\n"
        "## Findings\n| id | severity | disposition | summary |\n"
        "| --- | --- | --- | --- |\n\n## Closure Decision\n"
        "Objective status: achieved | not_achieved | indeterminate\n"
        "Objective evidence: one sentence tied to acceptance and the receipt\n\n"
        "## Verdict\nVerdict: pass|needs_work|blocked - next: one move\n```"
    )


def _next(root):
    used = set()
    for folder in (root / "prompts/for_coding_agent", root / "prompts/for_review_agent"):
        for path in folder.glob("*.md"):
            match = re.match(r"(\d{3})_", path.name)
            if match:
                used.add(int(match.group(1)))
    for value in range(1, 1000):
        if value not in used:
            return value
    raise ValueError("prompt number space exhausted")


def _memory(rm, item):
    memory = rm.get("memory")
    if not memory:
        return ""
    root = memory["root"].rstrip("/")
    lines = [f"Root: `{root}`", "", "Allowed read commands:"]
    lines += [f"- `llloom --root {root} {verb}`" for verb in memory["read_verbs"]]
    pages = item.get("memory_pages", memory.get("read_first_pages", []))
    if pages:
        lines += ["", "Read for this slice:"] + [f"- `{page}`" for page in pages]
    lines += [
        "",
        (
            "Cite claim or page ids used. Report stale or contradicted claims; "
            "do not hand-edit memory."
        ),
    ]
    return "\n".join(lines)


def _load(root):
    rm = roadmap.load(root)
    events = ledger.read(root / "05_governance/ledger.jsonl")
    return rm, events, ledger.fold(events, rm)




def _json(value):
    return json.dumps(value, ensure_ascii=False, indent=2) + "\n"


def _envelope(root, rm, item, current, events=None, *, historical=False):
    context_state = current
    if historical and current.get("resolution") == current.get("unblock_reason"):
        context_state = {**current, "unblock_reason": None}
    context = evidence.findings_context(root, context_state, events, item["id"])
    if current.get("blocker"):
        blocker = current["blocker"]
        label = "Historical blocker" if historical else "Original blocker"
        if isinstance(blocker, dict) and "path" in blocker:
            context += "\n\n" + label + ": " + _ref(root, blocker["path"], blocker["sha"])
            context += "\n" + evidence.read_excerpt(root, blocker["path"], 2048)
        else:
            context += "\n\n" + label + ":\n" + _json(blocker)
    if current.get("resolution"):
        resolution = current["resolution"]
        label = "Historical resolution" if historical else "Recorded resolution"
        context += "\n\n" + label + ": " + (
            resolution if isinstance(resolution, str) else _json(resolution)
        )
    return {
        "schema": "frutlups.envelope/2",
        "slice": item["id"],
        "round": current["round"],
        "title": item["title"],
        "objective": item["objective"].strip(),
        "acceptance": item["acceptance"],
        "non_goals": item.get("non_goals", []),
        "read_first": item.get("read_first", []),
        "allowed_prefixes": roadmap.effective_prefixes(rm, item),
        "forbidden": rm["forbidden"],
        "focused": item.get("focused") or rm["verification"].get("focused_default", []),
        "full": item.get("verification", rm["verification"]["full"]),
        "runtime": rm.get("runtime", {}),
        "timeout_seconds": rm["verification"].get("timeout_seconds", 600),
        "observation": rm["verification"].get("observation", "process"),
        "notes": item.get("notes", "").strip(),
        "findings": context.strip(),
        "memory": _memory(rm, item),
    }


def _values(envelope):
    values = {key: envelope[key] for key in ("title", "round", "objective", "memory")}
    values["slice_id"] = envelope["slice"]
    for key in ("acceptance", "non_goals"):
        values[key] = _bullets(envelope[key])
    values["read_first"] = _bullets([f"`{path}`" for path in envelope["read_first"]])
    for key in ("allowed_prefixes", "forbidden"):
        values[key] = ", ".join(f"`{path}`" for path in envelope[key])
    for key in ("focused", "full"):
        values[key] = _argv(envelope[key])
    if "runtime" in envelope:
        values["full"] += (
            "\n\nExecution policy: runtime "
            + json.dumps(envelope["runtime"], ensure_ascii=False, sort_keys=True)
            + f"; timeout {envelope['timeout_seconds']} seconds; "
            + f"observation {envelope['observation']}."
        )
    values["notes"] = (
        "Advisory context; mandatory gates belong in acceptance.\n\n" + envelope["notes"]
        if envelope["notes"]
        else ""
    )
    values["open_findings"] = envelope["findings"]
    return values


def _frozen(root, rm, events, item, current):
    issued = next(
        (
            event
            for event in reversed(events)
            if event["ev"] == "prompt"
            and event.get("slice") == item["id"]
            and event["round"] == current["round"]
        ),
        {},
    )
    ref = issued.get("envelope")
    if ref:
        path = c.repo_path(root, ref["path"])
        if c.sha(path) != ref["sha"]:
            raise ValueError("immutable acceptance envelope drift")
        return json.loads(path.read_text(encoding="utf-8"))
    return _envelope(root, rm, item, current, events)


def _diagnostics(root, envelope):
    messages = []
    for rel in envelope["read_first"]:
        path = c.repo_path(root, c.safe_rel(rel))
        if not path.is_file() or path.is_symlink():
            messages.append(f"missing required read: {rel} (future outputs belong in acceptance)")
    if re.search(r"\b(must|required|gate|shall)\b", envelope["notes"], re.IGNORECASE):
        messages.append("advisory notes contain gate language; move mandatory gates to acceptance")
    # Diagnose only explicit path references, without guessing prose into scope.
    for rel in re.findall(r"`([^`\n]+)`", "\n".join(envelope["acceptance"])):
        if re.search(r"\s", rel) or rel.startswith(("http:", "https:")):
            continue
        if "/" not in rel and not Path(rel).suffix:
            continue
        try:
            c.safe_rel(rel)
        except ValueError:
            continue
        outside = evidence.fence([{"path": rel}], envelope["allowed_prefixes"], [])
        if outside and rel not in envelope["read_first"]:
            messages.append(
                f"acceptance path outside writes: {rel}; declare architect ownership "
                "or admit its integration/docs/test writes"
            )
    return messages


def _sized(text, values, limit):
    size = len(text.encode("utf-8"))
    if size > limit:
        sections = ", ".join(
            f"{key}={len(str(value).encode('utf-8'))}" for key, value in values.items() if value
        )
        raise ValueError(
            f"prompt is {size} bytes; cap is {limit}; reduce admitted scope. "
            f"Section bytes: {sections}"
        )
    return text


def _finish(backend, sid, round_no):
    if backend == "manual":
        return ""
    example = {
        "schema": "frutlups.outcome/2",
        "slice": sid,
        "round": round_no,
        "invocation": "<runner-provided invocation id>",
        "outcome": "implemented",
        "requirement": "<affected acceptance requirement>",
        "reason": "<observed result>",
        "actor": "",
        "action": "",
        "remaining": [],
        "evidence": [],
        "authority": [],
    }
    return (
        "For this autonomous backend, replace the manual four-list Finish response with "
        "one JSON object using this exact schema (at most 16384 UTF-8 bytes):\n\n```json\n"
        + _json(example)
        + "```\nOutcome is implemented, blocked_authority, or "
        "blocked_environment. A blocker requires nonempty actor/action and bounded remaining "
        "work. Evidence entries are {path,sha}; authority entries are relative decision/budget "
        "paths. Preserve edits and report missing authority; never invent success or a budget. "
        "Use the invocation identity supplied by the runner."
    )


def _save(root, rel, text):
    path = c.repo_path(root, rel)
    if path.exists() or path.is_symlink():
        if (
            path.is_symlink()
            or not path.is_file()
            or c.sha(path) != c.evidence_sha_bytes(text.encode("utf-8"))
        ):
            raise ValueError(f"immutable evidence path already occupied: {rel}")
    else:
        c.artifact_text(path, text)
    return {"path": rel, "sha": c.evidence_sha_bytes(text.encode("utf-8"))}


def _ref(root, rel, digest=None):
    return f"`{rel}` (normalized evidence SHA-256 `{digest or c.sha(root / rel)}`)"


def _support(scope, label, text, artifacts):
    digest = c.evidence_sha_bytes(text.encode("utf-8"))
    rel = f"05_governance/reviews/{scope.split('-')[0].lower()}/{scope}_{digest[:16]}_{label}"
    artifacts.append((rel, text))
    return f"`{rel}` (normalized evidence SHA-256 `{digest}`; read as a file, starting at line 1)"


def _context(values, key, scope, artifacts):
    """Externalize supporting history, retaining complete hash-bound readable context."""
    text = values[key]
    if len(text.encode("utf-8")) > 2048:
        ref = _support(scope, "context.md", text.rstrip() + "\n", artifacts)
        excerpt = text.encode("utf-8")[:2048].decode("utf-8", "ignore")
        values[key] = "Complete findings and recovery context: " + ref + "\n\n" + excerpt
        values[key] += "\n\n[Context excerpt bounded; read the complete context file above.]"


def _diff_excerpt(diff):
    if len(diff.encode("utf-8")) <= 8192:
        return diff
    prefix = diff.encode("utf-8")[:8000].decode("utf-8", "ignore")
    return prefix + "\n```\n\n[Inline excerpt bounded; read the full diff page above.]"


def _issue_support(root, rm, events, scope, round_no, artifacts):
    known = {(event.get("path"), event.get("sha")) for event in events}
    for rel, text in artifacts:
        ref = _save(root, rel, text)
        if (rel, ref["sha"]) not in known:
            ledger.append(
                root / "05_governance/ledger.jsonl",
                {
                    "ev": "artifact",
                    "by": "architect",
                    "scope": scope,
                    "round": round_no,
                    "role": "evidence",
                    **ref,
                },
                rm,
            )


def _resumes_contract(events, sid):
    """Only an unconsumed exact-slice resolution retains the issued task."""
    for event in reversed(events):
        if event["ev"] == "prompt" and event.get("slice") == sid:
            return False
        if event["ev"] == "resolved" and event.get("scope") == sid:
            return True
    return False


def coding(root, sid, allow_dirty=False, *, preview=False, backend="manual"):
    rm, events, state = _load(root)
    ledger.require_artifacts(root, events)
    current = state["slices"].get(sid)
    if not current or current["step"] not in ("unstarted", "fix"):
        raise ValueError(f"{sid} is not ready for coding prompt")
    _, item = roadmap.slice_by_id(rm, sid)
    resuming = _resumes_contract(events, sid)
    envelope = _envelope(root, rm, item, current, events, historical=not resuming)
    if resuming:
        # A resolution supplies new authority, without silently replacing the task.
        ref = current["envelope"]
        prior = json.loads((root / ref["path"]).read_text(encoding="utf-8"))
        envelope = {**prior, "round": current["round"], "findings": envelope["findings"]}
    if current.get("blocker"):
        if current.get("manifest"):
            ref = current["manifest"]
            envelope["findings"] += "\n\nRetained changes: " + _ref(root, ref["path"], ref["sha"])
        if current.get("notes"):
            envelope["findings"] += (
                "\n\nPrevious notes: "
                + _ref(root, current["notes"], current.get("notes_sha"))
                + "\n"
                + evidence.read_excerpt(root, current["notes"], 2048)
            )
    latest_resolution = next(
        (event for event in reversed(events)
         if event["ev"] == "resolved" and event["scope"] == sid),
        None,
    )
    for event in events:
        if event["ev"] == "resolved" and event["scope"] == sid:
            label = ("Resolution authority" if resuming and event is latest_resolution
                     else "Historical resolution authority")
            authority = label + ": " + ", ".join(
                _ref(root, ref["path"], ref["sha"]) for ref in event["authority"]
            )
            envelope["findings"] = authority + "\n\n" + envelope["findings"]
    values = _values(envelope)
    values["outcome_contract"] = _finish(backend, sid, current["round"])
    artifacts = []

    def render(diagnose=False):
        return _render(
            root / "prompts/templates/coding_prompt.md",
            values,
            (
                ("Findings to resolve", "open_findings"),
                ("Memory", "memory"),
                ("Advisory notes", "notes"),
                ("Autonomous outcome", "outcome_contract"),
            ),
            True,
            limit=CODING_LIMIT,
            diagnose=diagnose,
        )

    text = render()
    if len(text.encode("utf-8")) > CODING_LIMIT and values["open_findings"]:
        _context(values, "open_findings", sid, artifacts)
        text = render()
        if len(text.encode("utf-8")) > CODING_LIMIT:
            if artifacts:
                rel, body = artifacts[0]
                ref = _ref(root, rel, c.evidence_sha_bytes(body.encode("utf-8")))
            else:
                ref = _support(sid, "context.md", values["open_findings"] + "\n", artifacts)
            values["open_findings"] = "Read complete findings and recovery context: " + ref
            text = render()
        envelope["findings"] = values["open_findings"]
    _sized(text, values, CODING_LIMIT)
    text = render(True)
    diagnostics = _diagnostics(root, envelope)
    for message in diagnostics:
        print(f"diagnostic: {message}", file=sys.stderr)
    if any(message.startswith("missing required read") for message in diagnostics):
        raise ValueError("prompt has missing required reads; correct read_first before issuance")
    baseline = evidence.prompt_baseline(root, rm, events, sid, allow_dirty)
    if preview:
        return text
    number = _next(root)
    event = {"ev": "prompt", "by": "architect", "slice": sid, "round": current["round"]}
    _issue_support(root, rm, events, sid, current["round"], artifacts)
    rel = f"05_governance/reviews/{sid.split('-')[0].lower()}/{sid}_r{current['round']}"
    event["envelope"] = _save(root, rel + "_envelope.json", _json(envelope))
    rel = f"prompts/for_coding_agent/{number:03d}_{sid}_r{current['round']}.md"
    event.update(_save(root, rel, text))
    if baseline:
        event["baseline"] = baseline
    ledger.append(root / "05_governance/ledger.jsonl", event, rm)
    return rel


def _receipt(root, current):
    rel = current["receipt"]
    prefix = "Verification passed. Complete receipt: " + _ref(root, rel)
    # Keep large receipt diagnostics behind the complete artifact reference.
    if (root / rel).stat().st_size <= 4096:
        prefix += "\n\n```json\n" + evidence.read_excerpt(root, rel, 4096).rstrip() + "\n```"
    return prefix


def _review_values(envelope, report):
    values = _values(envelope)
    values.update(
        diff_manifest="",
        diff_evidence="",
        coder_notes="",
        receipt="",
        prior_findings=envelope["findings"],
        report_path=report,
        finding_id_rule=f"Start every finding ID with `{envelope['slice']}-`.",
    )
    # The review template presents this as Prior findings, without duplicating it.
    values["open_findings"] = ""
    return values


def _render_review(root, values, *, diagnose=True):
    values["finding_updates"] = (
        "To change an older finding, add `## Finding updates` before Closure Decision with "
        "columns `source | sha | id | disposition | related`. Name the original report path, "
        "its normalized evidence SHA-256 (`sha`), exact finding ID and explicit disposition; "
        "related is linked IDs or `-`. "
        "An unrelated pass closes nothing. Only a human may waive findings."
    )

    def render(diagnostics=False):
        return _render(
            root / "prompts/templates/review_prompt.md",
            values,
            (
                ("Coder notes", "coder_notes"),
                ("Prior findings", "prior_findings"),
                ("Advisory notes", "notes"),
                ("Memory", "memory"),
                ("Finding reconciliation", "finding_updates"),
            ),
            True,
            diagnose=diagnostics,
        )

    text = render()
    # Externalize supporting excerpts before asking to reduce authority/scope.
    for key in ("diff_evidence", "coder_notes", "receipt", "diff_manifest", "prior_findings"):
        if len(text.encode("utf-8")) <= REVIEW_LIMIT:
            break
        refs = re.findall(
            r"`[^`\n]+` \((?:normalized evidence SHA-256|sha256) `[a-f0-9]{64}`[^)\n]*\)",
            values[key],
        )
        if refs:
            values[key] = "Complete evidence (read with file tools):\n" + _bullets(refs)
            text = render()
    _sized(text, values, REVIEW_LIMIT)
    return render(True) if diagnose else text


def review(root, sid, *, preview=False, backend="manual"):
    rm, events, state = _load(root)
    current = state["slices"].get(sid)
    if not current or current["step"] != "reviewing":
        raise ValueError(f"{sid} is not awaiting review")
    ledger.require_artifacts(root, events)
    _, item = roadmap.slice_by_id(rm, sid)
    envelope = _frozen(root, rm, events, item, current)
    report = (
        f"05_governance/reviews/{sid.split('-')[0].lower()}/{sid}_r{current['round']}_review.md"
    )
    values = _review_values(envelope, report)
    artifacts = []
    _context(values, "prior_findings", sid, artifacts)
    mandatory = _render_review(root, values, diagnose=False)
    cumulative = evidence.slice_changes(events, sid)
    ledger.require_product(root, current)
    integrity.require_active(root, current, events)
    current_paths = {item["path"] for item in current["changed"]}
    manifest = current.get("manifest")
    rows = [
        f"`{item['path']}` ({item['kind']}, normalized evidence SHA-256 `{item['sha']}`, "
        f"{'current round' if item['path'] in current_paths else 'earlier round'})"
        for item in (cumulative[:8])
    ]
    manifest_ref = (
        _ref(root, manifest["path"], manifest["sha"])
        if manifest
        else _support(sid, "paths.json", _json(cumulative), artifacts)
    )
    values["diff_manifest"] = (
        f"{len(cumulative)} cumulative paths. Complete manifest: {manifest_ref}"
    )
    values["diff_manifest"] += "\n\n" + _bullets(rows)
    if len(cumulative) > 8:
        values["diff_manifest"] += (
            f"\n- {len(cumulative) - 8} additional paths in the manifest."
        )
    values["receipt"] = _receipt(root, current)
    if current["notes"]:
        values["coder_notes"] = _ref(root, current["notes"], current.get("notes_sha"))
        values["coder_notes"] += "\n\n" + evidence.read_excerpt(root, current["notes"], 2048)
    if current.get("outcome"):
        ref = current["outcome"]
        values["coder_notes"] += "\n\nCoder outcome: " + _ref(root, ref["path"], ref["sha"])
        values["coder_notes"] += "\n" + evidence.read_excerpt(root, ref["path"], 2048)
    # Admission of the mandatory text precedes Git and any bulk file reads.
    room = REVIEW_LIMIT - len(mandatory.encode("utf-8")) - 12000
    if room < 1024:
        _render_review(root, values, diagnose=False)
        room = 1024
    diff = evidence.review_diff(root, current["changed"], min(24000, room))
    ref = _support(sid, "diff.md", diff + "\n", artifacts)
    values["diff_evidence"] = "Bounded diff page: " + ref + "\n\n" + _diff_excerpt(diff)
    text = _render_review(root, values)
    if preview:
        return text
    number = _next(root)
    _issue_support(root, rm, events, sid, current["round"], artifacts)
    rel = f"prompts/for_review_agent/{number:03d}_{sid}_r{current['round']}.md"
    ledger.append(
        root / "05_governance/ledger.jsonl",
        {
            "ev": "artifact",
            "by": "architect",
            "scope": sid,
            "round": current["round"],
            "role": "review_prompt",
            **_save(root, rel, text),
        },
        rm,
    )
    return rel


def _holistic_report_path(root, mid, events):
    base = f"05_governance/reviews/{mid.lower()}/{mid}_holistic"
    pattern = rf"`({re.escape(base)}(?:_\d+)?_review\.md)`"
    occupied = set()
    for event in events:
        if event["ev"] != "artifact" or event["scope"] != mid:
            continue
        if event["role"] == "holistic_report":
            occupied.add(event["path"])
        elif event["role"] == "holistic_prompt":
            occupied.update(
                re.findall(pattern, evidence.read_excerpt(root, event["path"], REVIEW_LIMIT))
            )
    number = 1
    while True:
        suffix = "" if number == 1 else f"_{number}"
        rel = f"{base}{suffix}_review.md"
        if rel not in occupied and not (root / rel).exists() and not (root / rel).is_symlink():
            return rel
        number += 1


def holistic(root, mid, *, preview=False, backend="manual"):
    rm, events, state = _load(root)
    progress = state.get("holistic", {}).get(mid, {})
    if progress.get("step") in ("blocked", "close_pending"):
        raise ValueError(f"{mid} has a persisted {progress['step']} holistic decision")
    milestone = next((item for item in rm["milestones"] if item["id"] == mid), None)
    if not (
        milestone
        and milestone["holistic_review"]
        and all(state["slices"][item["id"]]["step"] == "accepted" for item in milestone["slices"])
    ):
        raise ValueError(f"{mid} is not ready for holistic review")
    ledger.require_artifacts(root, events)
    envelopes = [
        _frozen(root, rm, events, item, state["slices"][item["id"]]) for item in milestone["slices"]
    ]
    envelope = {
        **envelopes[0],
        "slice": mid,
        "round": "holistic",
        "title": milestone["title"],
        "objective": f"Judge holistic closure of {mid} across its accepted slices.",
    }
    values = _review_values(envelope, _holistic_report_path(root, mid, events))
    for _, key in ENVELOPE_SECTIONS:
        if key in ("objective", "open_findings"):
            continue
        values[key] = "\n\n".join(
            f"### {item['slice']}\n\n{_values(item).get(key, '')}"
            for item in envelopes
            if _values(item).get(key)
        )
    values["prior_findings"] = "\n\n".join(
        item["findings"] for item in envelopes if item["findings"]
    )
    for event in events:
        if event["ev"] == "holistic_reviewed" and event["milestone"] == mid:
            values["prior_findings"] += (
                "\n\nPrevious holistic decision: "
                + event["verdict"]
                + "; report "
                + _ref(root, event["report"], event["sha"])
                + "\nUnresolved finding IDs: "
                + (", ".join(event["open"]) or "none")
            )
        if event["ev"] == "resolved" and event["scope"] == mid:
            values["prior_findings"] += "\n\nRecorded resolution: " + event["reason"]
            values["prior_findings"] += "\nAuthority: " + ", ".join(
                _ref(root, ref["path"], ref["sha"]) for ref in event["authority"]
            )
        if (
            event["ev"] == "artifact"
            and event.get("scope") == mid
            and event.get("role") in ("holistic_report", "holistic_decision")
        ):
            values["prior_findings"] += (
                "\n\nPrevious holistic decision: "
                + _ref(root, event["path"], event["sha"])
                + "\n"
                + evidence.read_excerpt(root, event["path"], 4096)
            )
    values["finding_id_rule"] = (
        "Every P0-P2 finding ID must start with the affected slice ID, "
        "for example `M001-S02-H1-F1`."
    )
    artifacts, rows, paths_by_slice, receipts = [], [], {}, []
    _context(values, "prior_findings", mid, artifacts)
    _render_review(root, values, diagnose=False)
    for item in milestone["slices"]:
        sid = item["id"]
        current = state["slices"][sid]
        integrity.require_active(root, current, events)
        cumulative = evidence.slice_changes(events, sid)
        paths_by_slice[sid] = [row["path"] for row in cumulative]
        rows += [{"slice": sid, **row} for row in cumulative]
        receipts.append(
            f"### {sid}\n\n"
            + _receipt(root, current)
            + "\n\nReview: "
            + _ref(root, current["report"])
        )
    values["receipt"] = "\n\n".join(receipts)
    values["diff_manifest"] = f"{len(rows)} cumulative paths. Complete manifest: " + _support(
        mid, "paths.json", _json(rows), artifacts
    )
    mandatory = _render_review(root, values, diagnose=False)
    room = max(
        1024,
        REVIEW_LIMIT - len(mandatory.encode("utf-8")) - 4096,
    )
    diff = evidence.holistic_diff(
        root, evidence.accepted_base(root, events, milestone), paths_by_slice, min(24000, room)
    )
    values["diff_evidence"] = diff
    values["diff_evidence"] = (
        "Bounded diff page: "
        + _support(mid, "diff.md", diff + "\n", artifacts)
        + "\n\n"
        + _diff_excerpt(diff)
    )
    text = _render_review(root, values)
    if preview:
        return text
    number = _next(root)
    _issue_support(root, rm, events, mid, "holistic", artifacts)
    rel = f"prompts/for_review_agent/{number:03d}_{mid}_holistic.md"
    ledger.append(
        root / "05_governance/ledger.jsonl",
        {
            "ev": "artifact",
            "by": "architect",
            "scope": mid,
            "round": "holistic",
            "role": "holistic_prompt",
            **_save(root, rel, text),
        },
        rm,
    )
    return rel


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("slice", nargs="?")
    parser.add_argument("--review", action="store_true")
    parser.add_argument("--holistic")
    parser.add_argument("--allow-dirty", action="store_true")
    parser.add_argument("--preview", action="store_true")
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--backend", choices=("manual", "autonomous"), default="manual")
    parser.add_argument("--root", type=Path, default=c.ROOT)
    args = parser.parse_args(argv)
    try:
        root = args.root.resolve()
        preview = args.preview or args.check

        def render():
            options = {"preview": preview, "backend": args.backend}
            if args.holistic:
                return holistic(root, args.holistic, **options)
            if not args.slice:
                raise ValueError("provide a slice or --holistic Mnnn")
            if args.review:
                return review(root, args.slice, **options)
            return coding(root, args.slice, args.allow_dirty, **options)

        if preview:
            with c.command_scope():
                result = render()
        else:
            with c.mutation(root):
                result = render()
        if args.check:
            print(f"Prompt check passed: {len(result.encode('utf-8'))} UTF-8 bytes.")
            for section in re.split(r"(?m)(?=^## )", result):
                print(f"{section.splitlines()[0]}: {len(section.encode('utf-8'))} bytes")
        else:
            print(result, end="" if preview else "\n")
        return 0
    except (KeyError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
